# Multiscale modeling of electrochemical processes - computational challenge

Topic: The computational challenge is supposed to test varying computational
implementations within DFT on problems relevant to electrocatalysis. Two
application cases will be tested:

1.	Adsorption energy of CO2 on Ag(211)
2.	Reaction barrier for the Volmer step on Au(111) in acidic conditions

In both cases the absolute energy at specified conditions and their potential
response should be analyzed.

Methods of choice might involve, but are not limited to:
-	Explicit charging
-	Environ
-	JDFT
-	VaspSol(++)
-	ESM/RISM
-	SJM
-	Sawtooth potential

Input structures for both application cases are provided in the respective
directories and possibly just running single point calculation on the structures suffices to make
a comparison. However, feel free to also test out varying solvation models from fully explicit to
implicit solvent and varying models for charging the interface.

Sadly, we will not be able to provide computational ressources for the
challenge. Thus, you will have to run the calculations on the cluster you ahve
available. Make sure you have the methods you want to test out installed and
ready at the point of the workshop.


Schedule for computational challenge:
-  Afternoon of: Monday (compulsory if you want to join the challenge), Thursday, Tuesday, Wed: optional
-  Thursday: 16;15-17:00: presentation of results, all of us present.
